package com.example.xmlprocessing.services;

public interface SeedService {
    void seedCategories();
    void seedProducts();
    void seedUsers();
}
