package com.example.xmlprocessing.services;

public interface CategoryService {
    void exportCategoriesByProductsCount();
}
