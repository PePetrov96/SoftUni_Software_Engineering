package com.example.xmlprocessing.services;

public interface ProductService {
    void exportProductsInRange(int min, int max);
}
