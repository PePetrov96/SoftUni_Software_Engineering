package com.example.xmlprocessing.services;

public interface UserService {
    void exportUsersWithSoldProducts();
    void exportUsersAndProducts();
}
