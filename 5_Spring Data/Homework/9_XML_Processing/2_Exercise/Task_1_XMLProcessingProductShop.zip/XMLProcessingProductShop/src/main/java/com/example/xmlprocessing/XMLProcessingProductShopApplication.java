package com.example.xmlprocessing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XMLProcessingProductShopApplication {
	public static void main(String[] args) {
		SpringApplication.run(XMLProcessingProductShopApplication.class, args);
	}
}