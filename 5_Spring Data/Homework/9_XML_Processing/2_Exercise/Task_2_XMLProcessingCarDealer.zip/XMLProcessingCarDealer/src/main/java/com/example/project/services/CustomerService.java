package com.example.project.services;

public interface CustomerService {
    void exportOrderedCustomers();

    void exportCustomerSales();
}
