package com.example.project.services;

public interface SeedService {
    void seedSuppliers();
    void seedParts();
    void seedCars();
    void seedCustomers();
    void seedSales();
}
