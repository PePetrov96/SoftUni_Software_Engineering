package com.example.project.services;

public interface SaleService {
    void exportSalesWithDiscounts();
}
