package com.example.project.services;

public interface SupplierService {
    void exportLocalSuppliers();
}
