package com.example.project.services;

public interface CarService {
    void exportToyotaCars();

    void exportCartsWithParts();
}
