package com.example.project.services;

public interface PartService {
}
