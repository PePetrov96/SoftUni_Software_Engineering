package com.example.jsonprocessing.services;

public interface CategoryService {
    void importCategoriesFromJson();
    void exportCategoriesByProductCount();
}
