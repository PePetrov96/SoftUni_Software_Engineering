package com.example.jsonprocessing.services;

public interface CarService {
    void seedData();
    void exportCarsFromMakeToyota();
    void exportCarsAndParts();
    void exportSalesWithDiscount();
}