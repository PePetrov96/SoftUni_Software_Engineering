package com.example.jsonprocessing.services;

public interface SaleService {
    void seedData();
}
