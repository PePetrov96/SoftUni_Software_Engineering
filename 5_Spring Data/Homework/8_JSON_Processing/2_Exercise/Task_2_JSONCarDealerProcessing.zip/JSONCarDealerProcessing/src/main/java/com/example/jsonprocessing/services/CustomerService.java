package com.example.jsonprocessing.services;

public interface CustomerService {
    void seedData();
    void exportOrderedCustomers();
    void exportTotalSaleByCustomer();
}
