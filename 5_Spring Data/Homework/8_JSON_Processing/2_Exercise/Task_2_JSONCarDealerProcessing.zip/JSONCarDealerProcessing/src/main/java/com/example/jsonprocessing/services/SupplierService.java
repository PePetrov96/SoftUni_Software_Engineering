package com.example.jsonprocessing.services;

public interface SupplierService {
    void seedData();
    void exportLocalSuppliers();
}