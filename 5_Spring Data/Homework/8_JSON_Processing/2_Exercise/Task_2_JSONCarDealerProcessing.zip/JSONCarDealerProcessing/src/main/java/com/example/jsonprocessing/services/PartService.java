package com.example.jsonprocessing.services;

public interface PartService {
    void seedData();
}
