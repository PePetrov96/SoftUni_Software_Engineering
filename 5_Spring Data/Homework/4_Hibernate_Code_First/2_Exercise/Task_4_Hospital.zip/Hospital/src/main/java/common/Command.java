package common;

public enum Command {
    AddPatient,
    AddVisitation,
    AddDiagnosis,
    AddMedicine,
    GivePatientVisitations,
    Command6,
    Command7,
    End
}