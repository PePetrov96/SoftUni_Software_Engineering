package com.example.accountsystem.services;

import com.example.accountsystem.model.Book;

public interface BookService {
    void registerBook(Book book);
}