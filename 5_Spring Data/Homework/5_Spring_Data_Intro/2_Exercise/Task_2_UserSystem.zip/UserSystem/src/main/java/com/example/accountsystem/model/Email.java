package com.example.accountsystem.model;

public @interface Email {
}
