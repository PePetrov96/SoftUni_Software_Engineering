package com.example.accountsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountSystemApplication {
	public static void main(String[] args) {
		SpringApplication.run(AccountSystemApplication.class, args);
	}
}