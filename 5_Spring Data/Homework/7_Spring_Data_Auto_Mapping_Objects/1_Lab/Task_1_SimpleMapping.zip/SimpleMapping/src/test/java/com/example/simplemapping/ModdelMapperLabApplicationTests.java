package com.example.simplemapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModdelMapperLabApplicationTests {

    @Test
    void contextLoads() {
    }

}
